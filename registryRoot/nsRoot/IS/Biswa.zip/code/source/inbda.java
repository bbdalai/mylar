

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class inbda

{
	// ---( internal utility methods )---

	final static inbda _instance = new inbda();

	static inbda _newInstance() { return new inbda(); }

	static inbda _cast(Object o) { return (inbda)o; }

	// ---( server methods )---




	public static final void javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(javaService)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

