drop user ISV6 cascade;
